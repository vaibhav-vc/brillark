BRILLARK – Mini Website (Host Ready)

📁 Files:
- index.html → Main homepage
- explore-kit.html → Links to all four kit pages
- kit pages: spark-kit.html, web-kit.html, sci-kit.html, creator-kit.html

🖼️ Assets (in /assets/):
- brillark-logo.png
- brillie.png
- ark.png

🧭 Linking:
All internal links are relative. You can host this locally, on GitHub Pages, or Netlify.

🌐 Recommended Setup:
1. Rename files if needed (no spaces)
2. Keep all files in one folder
3. Upload to host OR open index.html in a browser

Created with ⚡ by Vaibhav (Vaelion Skye)
